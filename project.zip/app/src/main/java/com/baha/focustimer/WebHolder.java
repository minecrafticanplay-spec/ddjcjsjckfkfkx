package com.baha.focustimer;

import android.content.Context;
import android.content.Intent;
import android.content.MutableContextWrapper;
import android.graphics.Color;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

public class WebHolder {
    static WebView web;
    static MutableContextWrapper ctx;
    static Context app;
    static boolean running = false;
    static boolean enabled = false;
    static final Handler main = new Handler(Looper.getMainLooper());
    static Runnable endTask;

    static WebView get(Context c) {
        if (web == null) {
            app = c.getApplicationContext();
            enabled = app.getSharedPreferences("ov", 0).getBoolean("on", false);
            ctx = new MutableContextWrapper(app);
            web = new WebView(ctx);
            WebSettings s = web.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            web.setBackgroundColor(Color.BLACK);
            web.setWebChromeClient(new WebChromeClient());
            web.addJavascriptInterface(new Bridge(), "Android");
            web.loadUrl("file:///android_asset/index.html");
        }
        return web;
    }

    static void toggle() {
        if (web != null) web.evaluateJavascript("nativeToggle()", null);
    }

    static void vibrate() {
        try {
            Vibrator v = (Vibrator) app.getSystemService(Context.VIBRATOR_SERVICE);
            v.vibrate(VibrationEffect.createWaveform(new long[]{0, 300, 150, 300}, -1));
        } catch (Exception e) { }
    }

    static class Bridge {
        @JavascriptInterface
        public void state(final boolean run, final double rem) {
            main.post(new Runnable() {
                public void run() {
                    running = run;
                    if (endTask != null) { main.removeCallbacks(endTask); endTask = null; }
                    if (run) {
                        endTask = new Runnable() {
                            public void run() {
                                endTask = null;
                                if (web != null) web.evaluateJavascript("nativeSync()", null);
                                vibrate();
                            }
                        };
                        main.postDelayed(endTask, (long) rem + 100);
                    }
                    MainActivity.keepOn();
                    OverlayService.refresh();
                }
            });
        }

        @JavascriptInterface
        public void overlay() {
            main.post(new Runnable() {
                public void run() {
                    if (!Settings.canDrawOverlays(app)) {
                        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + app.getPackageName()));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        app.startActivity(i);
                        Toast.makeText(app, "Allow \"Display over other apps\", then come back and press again", Toast.LENGTH_LONG).show();
                        return;
                    }
                    enabled = !enabled;
                    app.getSharedPreferences("ov", 0).edit().putBoolean("on", enabled).apply();
                    Toast.makeText(app, enabled ? "Floating circle ON (shows when you leave the app)" : "Floating circle OFF", Toast.LENGTH_LONG).show();
                }
            });
        }
    }
}
