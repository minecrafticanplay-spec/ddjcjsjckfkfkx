package com.baha.focustimer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;

public class OverlayService extends Service {
    static OverlayService inst;
    OverlayView view;
    WindowManager wm;

    static void refresh() {
        if (inst != null && inst.view != null) inst.view.postInvalidate();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("t", "Timer", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "t")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Focus Timer")
                .setContentText("Running in background")
                .setContentIntent(pi)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
        if (WebHolder.enabled && Settings.canDrawOverlays(this)) addOverlay();
    }

    void addOverlay() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        float dp = getResources().getDisplayMetrics().density;
        SharedPreferences sp = getSharedPreferences("ov", 0);
        int size = sp.getInt("size", (int) (64 * dp));
        int sw = getResources().getDisplayMetrics().widthPixels;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = sp.getInt("x", sw - size - (int) (16 * dp));
        lp.y = sp.getInt("y", (int) (200 * dp));
        view = new OverlayView(this, wm, lp);
        try {
            wm.addView(view, lp);
        } catch (Exception e) {
            view = null;
        }
    }

    @Override
    public void onDestroy() {
        if (view != null && wm != null) {
            try { wm.removeView(view); } catch (Exception e) { }
        }
        view = null;
        inst = null;
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }
}
