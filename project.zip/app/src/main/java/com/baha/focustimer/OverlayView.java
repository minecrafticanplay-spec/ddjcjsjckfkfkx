package com.baha.focustimer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;

public class OverlayView extends View {
    final WindowManager wm;
    final WindowManager.LayoutParams lp;
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Path tri = new Path();
    final Handler h = new Handler(Looper.getMainLooper());
    final ScaleGestureDetector sg;
    final float slop, dp;
    float dX, dY;
    int sX, sY, sS;
    boolean moved, resizing, scaling;

    final Runnable longRun = new Runnable() {
        public void run() {
            if (!moved && !scaling) {
                resizing = true;
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                invalidate();
            }
        }
    };

    public OverlayView(Context c, WindowManager wm, WindowManager.LayoutParams lp) {
        super(c);
        this.wm = wm;
        this.lp = lp;
        dp = c.getResources().getDisplayMetrics().density;
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        sg = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                setSize(Math.round(OverlayView.this.lp.width * d.getScaleFactor()));
                return true;
            }
        });
    }

    void setSize(int n) {
        n = Math.max((int) (40 * dp), Math.min((int) (320 * dp), n));
        int o = lp.width;
        if (n == o) return;
        lp.x -= (n - o) / 2;
        lp.y -= (n - o) / 2;
        lp.width = n;
        lp.height = n;
        try { wm.updateViewLayout(this, lp); } catch (Exception e) { }
        invalidate();
    }

    void save() {
        getContext().getSharedPreferences("ov", 0).edit()
                .putInt("size", lp.width).putInt("x", lp.x).putInt("y", lp.y).apply();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        sg.onTouchEvent(e);
        if (sg.isInProgress() || e.getPointerCount() > 1) {
            scaling = true;
            h.removeCallbacks(longRun);
            return true;
        }
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dX = e.getRawX(); dY = e.getRawY();
                sX = lp.x; sY = lp.y; sS = lp.width;
                moved = false; resizing = false; scaling = false;
                h.postDelayed(longRun, 500);
                return true;
            case MotionEvent.ACTION_MOVE: {
                if (scaling) return true;
                float dx = e.getRawX() - dX, dy = e.getRawY() - dY;
                if (resizing) {
                    setSize(sS + Math.round(dx + dy));
                    return true;
                }
                if (!moved && Math.hypot(dx, dy) > slop) {
                    moved = true;
                    h.removeCallbacks(longRun);
                }
                if (moved) {
                    lp.x = sX + Math.round(dx);
                    lp.y = sY + Math.round(dy);
                    try { wm.updateViewLayout(this, lp); } catch (Exception ex) { }
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
                h.removeCallbacks(longRun);
                if (!moved && !resizing && !scaling) WebHolder.toggle();
                resizing = false; scaling = false;
                invalidate();
                save();
                return true;
            case MotionEvent.ACTION_CANCEL:
                h.removeCallbacks(longRun);
                resizing = false; scaling = false;
                invalidate();
                return true;
        }
        return true;
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), m = w / 2f, s = w / 240f;
        float sw = Math.max(3f, w * 0.05f);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xE6000000);
        c.drawCircle(m, m, m - sw / 2f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(sw);
        p.setColor(resizing ? 0xFF4FC3F7 : 0xFF888888);
        c.drawCircle(m, m, m - sw / 2f, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFDDDDDD);
        if (WebHolder.running) {
            c.drawRect(92 * s, 86 * s, 114 * s, 154 * s, p);
            c.drawRect(126 * s, 86 * s, 148 * s, 154 * s, p);
        } else {
            tri.reset();
            tri.moveTo(98 * s, 84 * s);
            tri.lineTo(98 * s, 156 * s);
            tri.lineTo(158 * s, 120 * s);
            tri.close();
            c.drawPath(tri, p);
        }
    }
}
