package com.baha.focustimer;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    static MainActivity cur;
    FrameLayout root;
    WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        cur = this;
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        web = WebHolder.get(this);
        WebHolder.ctx.setBaseContext(this);
        if (web.getParent() != null) ((ViewGroup) web.getParent()).removeView(web);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        keepOn();
    }

    @Override
    protected void onStart() {
        super.onStart();
        stopService(new Intent(this, OverlayService.class));
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (WebHolder.enabled || WebHolder.running) {
            if (WebHolder.enabled && !Settings.canDrawOverlays(this)) WebHolder.enabled = false;
            try {
                startForegroundService(new Intent(this, OverlayService.class));
            } catch (Exception e) { }
        }
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (root != null) root.removeView(web);
        if (WebHolder.ctx != null) WebHolder.ctx.setBaseContext(WebHolder.app);
        if (cur == this) cur = null;
    }

    static void keepOn() {
        if (cur == null) return;
        if (WebHolder.running) cur.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else cur.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
}
