package com.baha.adcover

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout

class AdCoverService : AccessibilityService() {

    private val telegramPackages = setOf(
        "org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram"
    )
    // كلمات تدل على الرسالة الإعلانية (Sponsored) بعدة لغات
    private val adKeywords = listOf("sponsored", "إعلان", "ممول", "реклама", "publicidad", "werbung")

    private lateinit var wm: WindowManager
    private lateinit var container: FrameLayout
    private var lastRects: List<Rect> = emptyList()

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        container = FrameLayout(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(container, lp)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow
        if (root == null || root.packageName?.toString() !in telegramPackages) {
            draw(emptyList()); return
        }
        val rects = mutableListOf<Rect>()
        scan(root, rects)
        draw(rects)
    }

    private fun scan(node: AccessibilityNodeInfo, out: MutableList<Rect>) {
        if (isAdMarker(node)) {
            val cell = findCell(node)
            collectImages(cell, out)
            return
        }
        for (i in 0 until node.childCount) node.getChild(i)?.let { scan(it, out) }
    }

    private fun isAdMarker(n: AccessibilityNodeInfo): Boolean {
        val s = ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).lowercase()
        return s.isNotBlank() && adKeywords.any { s.contains(it) }
    }

    // نصعد حتى نصل لعنصر القائمة (ابن العنصر القابل للتمرير)
    private fun findCell(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
        var cur = n
        while (true) {
            val p = cur.parent ?: return cur
            if (p.isScrollable) return cur
            cur = p
        }
    }

    private fun collectImages(cell: AccessibilityNodeInfo, out: MutableList<Rect>) {
        val before = out.size
        fun walk(n: AccessibilityNodeInfo) {
            if (n.className?.toString()?.endsWith("ImageView") == true) {
                val r = Rect(); n.getBoundsInScreen(r)
                if (r.width() > 80 && r.height() > 80) out.add(r)
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(cell)
        // تيليجرام يرسم الرسائل بشكل مخصص؛ إن لم نجد صورة نغطي كامل الإعلان
        if (out.size == before) {
            val r = Rect(); cell.getBoundsInScreen(r)
            if (r.width() > 0 && r.height() > 0) out.add(r)
        }
    }

    private fun draw(rects: List<Rect>) {
        if (rects == lastRects) return
        lastRects = rects.map { Rect(it) }
        container.removeAllViews()
        for (r in rects) {
            val v = View(this).apply { setBackgroundColor(Color.parseColor("#1C1C1E")) }
            container.addView(v, FrameLayout.LayoutParams(r.width(), r.height()).apply {
                leftMargin = r.left; topMargin = r.top
            })
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        if (::container.isInitialized) runCatching { wm.removeView(container) }
        super.onDestroy()
    }
}
