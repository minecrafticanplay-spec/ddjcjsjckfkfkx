# Telegram Ad Cover
Android accessibility service that covers images inside Telegram "Sponsored" messages only.
Build: push to GitHub → Actions → Build APK → download artifact. Then enable the service in Settings → Accessibility.
